﻿using System.Diagnostics;
using System.Diagnostics.Metrics;

class Program
{
    static void Main(string[] args)
    {
        //Ejercicio NO.01 ; en clase ; Laboratorio 6

        int numero;
        string entrada;
        string mesCadena;

        Console.WriteLine("Eejercico NO.01 ; Laboratorio 06");

        Console.WriteLine("Por favor, ingrese un númeor entero del 1 al 12");
        entrada = Console.ReadLine();

        if(int.TryParse(entrada, out numero))
        {
            Console.WriteLine($"se convirtió '{entrada}' a '{numero}'");
        }
        else
        {
            Console.WriteLine("Error: Por favor ingrese un número entero del 1 al 12");
        }

        Console.WriteLine(numero);

        switch(numero)
        {
            case 1:
            mesCadena = "Enero";
            break;

            case 2:
            mesCadena = "Febrero";
            break;

            case 3:
            mesCadena = "Marzo";
            break;

            case 4:
            mesCadena = "Abril";
            break;

            case 5:
            mesCadena = "Mayo";
            break;

            case 6:
            mesCadena = "Junio";
            break;

            case 7:
            mesCadena = "Julio";
            break;

            case 8:
            mesCadena = "Agosto";
            break;

            case 9:
            mesCadena = "Septiembre";
            break;

            case 10:
            mesCadena = "Octubre";
            break;

            case 11:
            mesCadena = "Noviembre";
            break;

            case 12:
            mesCadena = "Diciembre";
            break;

            //

            default:
            mesCadena = " ";
            Console.WriteLine("Error: Por favor ingrese un número entero del 1 al 12");
            break;
        }

        Console.WriteLine($"Mes: '{mesCadena}'");

        //Ejercicio NO.02 ; Laboratoio 6

        int NUM1;
        int NUM2;
        int NUM3;
        string A;
        string B;
        string C;
        int a;
        int b;
        int c;
        int mayor;
        int menor;

        Console.WriteLine("Eejercico NO.02 ; Laboratorio 06");

        Console.WriteLine("Por favor, ingrese a");
        A = Console.ReadLine();
        Console.WriteLine("Por favor, ingrese b");
        B = Console.ReadLine();
        Console.WriteLine("Por favor, ingrese c");
        C = Console.ReadLine();

        if(int.TryParse(A, out NUM1))
        {
            Console.WriteLine($"se convirtió '{A}' a '{NUM1}'");
            if(int.TryParse(B, out NUM2))
            {
                Console.WriteLine($"se convirtió '{B}' a '{NUM2}'");
                if(int.TryParse(C, out NUM3))
                {
                    Console.WriteLine($"se convirtió '{C}' a '{NUM3}'");
        
                    Console.WriteLine("Por favor, confirme a");
                    a = Int32.Parse(Console.ReadLine());
                    Console.WriteLine("Por favor, confirme b");
                    b = Int32.Parse(Console.ReadLine());
                    Console.WriteLine("Por favor, confirme c");
                    c = Int32.Parse(Console.ReadLine());

                    if (a <= 0)
                    {
                        Console.WriteLine("ERROR: por favor ingrese un número entero difrente y mayor que 0 para a");
                    }
                    else
                    {
                        if (b <= 0)
                        {
                            Console.WriteLine("EROR: por favor ingrese un número entero difrente y mayor que 0 para b");
                        }
                        else
                        {
                            if (c <= 0)
                            {
                                Console.WriteLine("ERROR: por favor ingrese un número entero difrente y mayor que 0 para c");
                            }
                            else
                            {
                                if (a == b)
                                {
                                    if (b == c)
                                    {
                                        Console.WriteLine(a + " , " + b + " y " + c + " son iguales");
                                    }
                                    else
                                    {
                                        if (b > c)
                                        {
                                            Console.WriteLine("RESULTADO: " + a + " y " + b + " son mmenores que " + c);
                                        }
                                        else
                                        {
                                            Console.WriteLine("RESULTADO: " + a + " y " + b + " son menores que " + c);
                                        }
                                    }
                                }
                                else
                                {
                                    if (b == c)
                                    {
                                        if (c > a)
                                        {
                                            Console.WriteLine("RESULTADO: " + b + " y " + c + " son mayores  que " + a);
                                        }
                                        else 
                                        {
                                            Console.WriteLine("RESULTADO: " + b + " y " + c + " son menores que " + a);
                                        }
                                    }
                                    else
                                    {
                                        if (a == c)
                                        {
                                            if (c > b)
                                            {
                                                Console.WriteLine("RESULTADO: " + a + " y " + c + " son mayores que " + b);
                                            }
                                            else
                                            {
                                                Console.WriteLine("RESULTADO: " + a + " y " + c + " son menores que " + b);
                                            }
                                        }
                                        else
                                        {
                                            mayor = a;
                                            if (mayor < b) mayor = b;
                                            if (mayor < c) mayor = c;

                                            menor = a;
                                            if (menor > b) menor = b;
                                            if (menor > c) menor = c;

                                            Console.WriteLine("RESULTADO: el mayor de los tres número es " + mayor);
                                            Console.WriteLine("RESULTADO: el menor de los tres números es " + menor);
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                else
                {
                    Console.WriteLine("ERROR: por favor ingrese un número entero difrente y mayor que 0");
                }
                Console.WriteLine("c = " + NUM3);
            }
            else
            {
                    Console.WriteLine("ERROR: por favor ingrese un número entero difrente y mayor que 0");
            }
            Console.WriteLine("b = " + NUM2);
        }
        else
        {
            Console.WriteLine("ERROR: por favor ingrese un número entero difrente y mayor que 0");
        }
        Console.WriteLine("a = " + NUM1);

        // Tarea ; en casa ; Laboratorio 6

        string día;
        string mes;
        string año;
        int treinta;

        Console.WriteLine("Tarea ; Laboratorio 06");
        Console.WriteLine("T7 . MNLL . 1102124");

        Console.WriteLine("Por favor, ingrese su año de nacimiento: ");
        año = Console.ReadLine();
        Console.WriteLine("Por favor, ingrese su mes de nacimiento (textual): ");
        mes = Console.ReadLine();

        Console.WriteLine("Por favor, ingrese su día de nacimiento (numérico): ");
        día = Console.ReadLine();

        if(int.TryParse(día, out treinta))
        {
            Console.WriteLine($"se convirtió '{día}' a '{treinta}'");
        }
        else
        {
            Console.WriteLine("Error: Por favor ingrese un número entero del 1 al 31 para día");
        }

        switch(mes)
        {
            case "Enero":
                if (treinta <= 19)
                {
                    Console.WriteLine("Usted nació en " + año + "/" + mes + "/" + treinta + " así que su signo del zodiaco es: Capricornio");
                }
                else
                {
                    Console.WriteLine("Usted nació en " + año + "/" + mes + "/" + treinta + " así que su signo del zodiaco es: Acuario");
                }
            break;

            case "Febrero":
                if (treinta <= 18)
                {
                    Console.WriteLine("Usted nació en " + año + "/" + mes + "/" + treinta + " así que su signo del zodiaco es: Acuario");
                }
                else
                {
                    Console.WriteLine("Usted nació en " + año + "/" + mes + "/" + treinta + " así que su signo del zodiaco es: Piscis");
                }
            break;

            case "Marzo":
                if (treinta <= 20)
                {
                    Console.WriteLine("Usted nació en " + año + "/" + mes + "/" + treinta + " así que su signo del zodiaco es: Piscis");
                }
                else
                {
                    Console.WriteLine("Usted nació en " + año + "/" + mes + "/" + treinta + " así que su signo del zodiaco es: Aries");
                }
            break;

            case "Abril":
                if (treinta <= 19)
                {
                    Console.WriteLine("Usted nació en " + año + "/" + mes + "/" + treinta + " así que su signo del zodiaco es: Aries");
                }
                else
                {
                    Console.WriteLine("Usted nació en " + año + "/" + mes + "/" + treinta + " así que su signo del zodiaco es: Tauro");
                }
            break;

            case "Mayo":
                if (treinta <= 20)
                {
                    Console.WriteLine("Usted nació en " + año + "/" + mes + "/" + treinta + " así que su signo del zodiaco es: Tauro");
                }
                else
                {
                    Console.WriteLine("Usted nació en " + año + "/" + mes + "/" + treinta + " así que su signo del zodiaco es: Géminis");
                }
            break;

            case "Junio":
                if (treinta <= 20)
                {
                    Console.WriteLine("Usted nació en " + año + "/" + mes + "/" + treinta + " así que su signo del zodiaco es: Géminis");
                }
                else
                {
                    Console.WriteLine("Usted nació en " + año + "/" + mes + "/" + treinta + " así que su signo del zodiaco es: Cacer");
                }
            break;

            case "Julio":
                if (treinta <= 22)
                {
                    Console.WriteLine("Usted nació en " + año + "/" + mes + "/" + treinta + " así que su signo del zodiaco es: Cancer");
                }
                else
                {
                    Console.WriteLine("Usted nació en " + año + "/" + mes + "/" + treinta + " así que su signo del zodiaco es: Leo");
                }
            break;

            case "Agosto":
                if (treinta <= 22)
                {
                    Console.WriteLine("Usted nació en " + año + "/" + mes + "/" + treinta + " así que su signo del zodiaco es: Leo");
                }
                else
                {
                    Console.WriteLine("Usted nació en " + año + "/" + mes + "/" + treinta + " así que su signo del zodiaco es: Virgo");
                }
            break;

            case "Septiembre":
                if (treinta <= 22)
                {
                    Console.WriteLine("Usted nació en " + año + "/" + mes + "/" + treinta + " así que su signo del zodiaco es: Virgo");
                }
                else
                {
                    Console.WriteLine("Usted nació en " + año + "/" + mes + "/" + treinta + " así que su signo del zodiaco es: Libra");
                }
            break;

            case "Octubre":
                if (treinta <= 22)
                {
                    Console.WriteLine("Usted nació en " + año + "/" + mes + "/" + treinta + " así que su signo del zodiaco es: Libra");
                }
                else
                {
                    Console.WriteLine("Usted nació en " + año + "/" + mes + "/" + treinta + " así que su signo del zodiaco es: Escorpio");
                }
            break;

            case "Noviembre":
                if (treinta <= 21)
                {
                    Console.WriteLine("Usted nació en " + año + "/" + mes + "/" + treinta + " así que su signo del zodiaco es: Escorpio");
                }
                else
                {
                    Console.WriteLine("Usted nació en " + año + "/" + mes + "/" + treinta + " así que su signo del zodiaco es: Sagitario");
                }
            break;

            case "Diciembre":
                if (treinta <= 21)
                {
                    Console.WriteLine("Usted nació en " + año + "/" + mes + "/" + treinta + " así que su signo del zodiaco es: Sagitario");
                }
                else
                {
                    Console.WriteLine("Usted nació en " + año + "/" + mes + "/" + treinta + " así que su signo del zodiaco es: Capricornio");
                }
            break;

            case "enero":
                if (treinta <= 19)
                {
                    Console.WriteLine("Usted nació en " + año + "/" + mes + "/" + treinta + " así que su signo del zodiaco es: Capricornio");
                }
                else
                {
                    Console.WriteLine("Usted nació en " + año + "/" + mes + "/" + treinta + " así que su signo del zodiaco es: Acuario");
                }
            break;

            case "febrero":
                if (treinta <= 18)
                {
                    Console.WriteLine("Usted nació en " + año + "/" + mes + "/" + treinta + " así que su signo del zodiaco es: Acuario");
                }
                else
                {
                    Console.WriteLine("Usted nació en " + año + "/" + mes + "/" + treinta + " así que su signo del zodiaco es: Piscis");
                }
            break;

            case "marzo":
                if (treinta <= 20)
                {
                    Console.WriteLine("Usted nació en " + año + "/" + mes + "/" + treinta + " así que su signo del zodiaco es: Piscis");
                }
                else
                {
                    Console.WriteLine("Usted nació en " + año + "/" + mes + "/" + treinta + " así que su signo del zodiaco es: Aries");
                }
            break;

            case "abril":
                if (treinta <= 19)
                {
                    Console.WriteLine("Usted nació en " + año + "/" + mes + "/" + treinta + " así que su signo del zodiaco es: Aries");
                }
                else
                {
                    Console.WriteLine("Usted nació en " + año + "/" + mes + "/" + treinta + " así que su signo del zodiaco es: Tauro");
                }
            break;

            case "mayo":
                if (treinta <= 20)
                {
                    Console.WriteLine("Usted nació en " + año + "/" + mes + "/" + treinta + " así que su signo del zodiaco es: Tauro");
                }
                else
                {
                    Console.WriteLine("Usted nació en " + año + "/" + mes + "/" + treinta + " así que su signo del zodiaco es: Géminis");
                }
            break;

            case "junio":
                if (treinta <= 20)
                {
                    Console.WriteLine("Usted nació en " + año + "/" + mes + "/" + treinta + " así que su signo del zodiaco es: Géminis");
                }
                else
                {
                    Console.WriteLine("Usted nació en " + año + "/" + mes + "/" + treinta + " así que su signo del zodiaco es: Cacer");
                }
            break;

            case "julio":
                if (treinta <= 22)
                {
                    Console.WriteLine("Usted nació en " + año + "/" + mes + "/" + treinta + " así que su signo del zodiaco es: Cancer");
                }
                else
                {
                    Console.WriteLine("Usted nació en " + año + "/" + mes + "/" + treinta + " así que su signo del zodiaco es: Leo");
                }
            break;

            case "agosto":
                if (treinta <= 22)
                {
                    Console.WriteLine("Usted nació en " + año + "/" + mes + "/" + treinta + " así que su signo del zodiaco es: Leo");
                }
                else
                {
                    Console.WriteLine("Usted nació en " + año + "/" + mes + "/" + treinta + " así que su signo del zodiaco es: Virgo");
                }
            break;

            case "septiembre":
                if (treinta <= 22)
                {
                    Console.WriteLine("Usted nació en " + año + "/" + mes + "/" + treinta + " así que su signo del zodiaco es: Virgo");
                }
                else
                {
                    Console.WriteLine("Usted nació en " + año + "/" + mes + "/" + treinta + " así que su signo del zodiaco es: Libra");
                }
            break;

            case "octubre":
                if (treinta <= 22)
                {
                    Console.WriteLine("Usted nació en " + año + "/" + mes + "/" + treinta + " así que su signo del zodiaco es: Libra");
                }
                else
                {
                    Console.WriteLine("Usted nació en " + año + "/" + mes + "/" + treinta + " así que su signo del zodiaco es: Escorpio");
                }
            break;

            case "noviembre":
                if (treinta <= 21)
                {
                    Console.WriteLine("Usted nació en " + año + "/" + mes + "/" + treinta + " así que su signo del zodiaco es: Escorpio");
                }
                else
                {
                    Console.WriteLine("Usted nació en " + año + "/" + mes + "/" + treinta + " así que su signo del zodiaco es: Sagitario");
                }
            break;

            case "diciembre":
                if (treinta <= 21)
                {
                    Console.WriteLine("Usted nació en " + año + "/" + mes + "/" + treinta + " así que su signo del zodiaco es: Sagitario");
                }
                else
                {
                    Console.WriteLine("Usted nació en " + año + "/" + mes + "/" + treinta + " así que su signo del zodiaco es: Capricornio");
                }
            break;

            //

            default:
            mes = " ";
            Console.WriteLine("Error: No ha ingresado un nombre de mes válido");
            break;
        }

        Console.WriteLine("Gracias por la interacción, que tenga un buen día.");
    }
}