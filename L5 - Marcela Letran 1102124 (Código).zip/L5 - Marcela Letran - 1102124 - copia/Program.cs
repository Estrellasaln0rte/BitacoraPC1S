﻿class Program
{
    static void Main(string[] args)
    {
        string nombre;
        Console.WriteLine("Ingrese su nombre");
        nombre = Console.ReadLine();
        Console.WriteLine ("Hola " + nombre);

        //Práctica de laboratorio

        //1. Operaciones aritméticas

        Console.WriteLine("Parte 1, ejercicio NO.01");
        double numero1;
        double nuemro2;
        double suma;
        double resta;
        double multiplicación;
        double división;
        Console.WriteLine("Por favor " + nombre + ", ingresa el primer valor operable");
        numero1 = Convert.ToDouble(Console.ReadLine());
        Console.WriteLine("Ahora, ingresa el segundo valor operable");
        nuemro2 = Convert.ToDouble(Console.ReadLine());
        suma = numero1 + nuemro2;
        resta = numero1 - nuemro2;
        multiplicación = numero1 * nuemro2;
        división = numero1 / nuemro2;
        Console.WriteLine(numero1 + "+" + nuemro2 + "=" + suma);
        Console.WriteLine(numero1 + "-" + nuemro2 + "=" + resta);
        Console.WriteLine(numero1 + "*" + nuemro2 + "=" + multiplicación);
        Console.WriteLine(numero1 + "/" + nuemro2 + "=" + división);

        //2. Operaciones booleanas

        Console.WriteLine("Parte 2, ejercicio NO.02");
        if (numero1 == nuemro2)
        {
            Console.WriteLine(numero1 + " = " + nuemro2);
        }
        else 
        {
            if (numero1 > nuemro2)
            {
                Console.WriteLine(numero1 + " > " + nuemro2 + " , " + nuemro2 + " < " + numero1 + " , " + numero1 + " ≠ " + nuemro2);
            }
            else
            {
                Console.WriteLine(numero1 + " < " + nuemro2 + " , " + nuemro2 + " > " + numero1 + " , " + numero1 + " ≠ " + nuemro2);
            }

        }

        // 3. Jerarquía de operaciones

        Console.WriteLine("Parte 2, ejercicio NO.03");
        double a;
        double b;
        double c;
        double d;
        double e;
        double f;
        double g;
        double h;
        double op1;
        double op2;
        double op3;
        double op4;
        double op5;
        double op6;
        double op7;
        double raíz;
        Console.WriteLine("Por favor " + nombre + ", ingresa el nuevo valor A operable");
        a = Convert.ToDouble(Console.ReadLine());
        Console.WriteLine("Ahora, ingresa el valor B operable");
        b = Convert.ToDouble(Console.ReadLine());
        Console.WriteLine("Ahora, ingresa el valor C operable");
        c = Convert.ToDouble(Console.ReadLine());
        d = 3;
        e = 2;
        f = 4;
        g = -1;
        h = ((b*b)-(f*a*c));
        op1 = ((a*b)+c);
        op2 = (a*(a+b)); 
        op3 = ((a)/(b*c)); 
        op4 = (((d*a)+(e*b))/(c*c)); 
        op5 = ((b*b)-(f*a*c));
        raíz = Math.Sqrt(h);
        op6 = (((b*g)+(raíz))/(e*a));
        op7 = (((b*g)-(raíz))/(e*a));
        Console.WriteLine("El total de la operación 1 (" + a + "*" + b + "+" + c + ") es: " + op1);
        Console.WriteLine("El total de la operación 2 (" + a + "*" + "(" + b + "+" + c + ")) es: " + op2);
        Console.WriteLine("El total de la operación 3 (" + a + "/" + "(" + b + "*" + c + ")) es: " + op3);
        Console.WriteLine("El total de la operación 4 (" + "3(" + a + ")+2(" + b + "))/" + c + "²) es: " + op4);

        // 3. Jerarquía de operaciones

        Console.WriteLine("Parte 2, ejercicio NO.04");

        if (a == 0)
        {
            Console.WriteLine("No es operable debidoa  que " + a + " = 0");
        }
        else
        {
            if (op5 !>= 0)
            {
                Console.WriteLine("No es operable debido a  que " + b + "² - 4*" + a + "*" + c + " < 0");
            }
            else 
            {
                Console.WriteLine("El resultado de la ecuación (-" + b + " ± √(" + b + "² - 4(" + a + ")(" + c + ")) / 2(" + a + ") es igaul a x₁ = " + op6 + " ; x₂ = " + op7);
            }
        }

        //Fin de los ejercicio solicitados

        Console.WriteLine("Gracias por tu tiempo " + nombre + ", ten un buen día.");
    }

}