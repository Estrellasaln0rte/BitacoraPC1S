﻿using L9___Marcela_Letran___1102124;

namespace Prueba
{
    class Program
    {
        static void Main ()
        {
            Automovil objAutomovil = new Automovil();

            objAutomovil.IngresarDatos();
            objAutomovil.MostrarInformacion();
            objAutomovil.CambiarDisponibilidad();
            objAutomovil.MostrarInformacion();
            objAutomovil.AplicarDescuento();
            objAutomovil.MostrarInformacion();
        }
    }
}