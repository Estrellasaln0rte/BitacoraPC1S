﻿using System.Reflection.Metadata.Ecma335;
using System.Text.RegularExpressions;

namespace L9___Marcela_Letran___1102124;

public class Automovil
{
    private int modelo;
    private double precio;
    private string marca;
    private bool disponible;
    private double tipoCambioDolar;
    private double descuentoAplicado;

    public Automovil()
    {
        modelo = 2019;
        precio = 10000.00;
        marca = "";
        disponible = false;
        tipoCambioDolar = 7.50;
        descuentoAplicado = 1;
    }
    public void DefinirModelo (int unModelo)
    {
        modelo = unModelo;
    }
    public double DefinirPrecio ()
    {
        return precio * descuentoAplicado;
    }
    public string DefinriMarca (string unaMarca)
    {
        return marca;
    }
    public double DefinirTipoCambio (double unTipoCambio)
    {
        return tipoCambioDolar;
    }
    public void CambiarDisponibilidad ()
    {
        Console.Write ("¿Desea cambiar disponibilidad (Disponibilidad actual: " + MostrarDisponiblidad() + ")? : ");
        string disponibleUsuario = Console.ReadLine();
        if (disponibleUsuario.ToLower() == "si")
        {
            disponible = !disponible;
        }
    }
    public string MostrarDisponiblidad ()
    {
        if (disponible == true)
        {
            return "Disponible";
        }
        else
        {
            return "No se encuentra disponible actualmente";
        }
    }
    public void AplicarDescuento ()
    {
        Console.Write ("¿Desea aplicar un descuento? : ");
        string descuentoUsuario = Console.ReadLine();
        if (descuentoUsuario == "si")
        {
            Console.Write ("Por favor, ingrese el descuento a aplicar: ");
        descuentoAplicado = Convert.ToDouble(Console.ReadLine());
        double miDescuento = DefinirPrecio();
        }
    }
    public void IngresarDatos()
    {
        Console.Write ("Por favor, ingrese el modelo: ");
        modelo = Convert.ToInt32(Console.ReadLine());

        Console.Write ("Por favor, ingrese el precio: ");
        precio = Convert.ToDouble(Console.ReadLine());

        Console.Write ("Por favor, ingrese la marca: ");
        marca = Console.ReadLine();

        Console.Write ("Por favor, ingrese el tipo de cambio: ");
        tipoCambioDolar = Convert.ToDouble(Console.ReadLine());
    }
    public void MostrarInformacion ()
    {
        double precioFinal = DefinirPrecio();
        double precioEnDolares = precioFinal * tipoCambioDolar;
        Console.WriteLine ("Marca: " + marca + ". Modelo: " + modelo + ". Precio de venta: Q" + precioFinal + ". Precio en dólares $" + precioEnDolares + ". " + MostrarDisponiblidad());
    }
}