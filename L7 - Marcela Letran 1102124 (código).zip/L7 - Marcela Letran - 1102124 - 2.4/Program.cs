﻿class Program
{
    static void Main(string[] args)
    {
        int NFibonacci;
        bool conversionAINT = false;
        bool nPositivo = false;
        int INT = 2;
        int CERO = 0;
        int nINT = 1;
        int resultado;
        int B;
        int A;
    
        Console.WriteLine("Laboratorio NO.07 ; Marcela Letran : 1102124");
        do
        {
            Console.WriteLine("Ingrese un númeor entero distinto y mayor a 0");
            conversionAINT = int.TryParse(Console.ReadLine(), out NFibonacci);
            if (conversionAINT)
            {
                if (NFibonacci > 0)
                {
                    nPositivo = true;
                }
            }
        }
        while (!conversionAINT || !nPositivo);

        Console.WriteLine("Secuencia");

        if (NFibonacci > 0)
        {
            A = 0;
            Console.WriteLine(A);
            if (NFibonacci > 1)
            {
                B = 1;
                Console.WriteLine(B);
                while (INT < NFibonacci)
                {
                    ++INT;
                    resultado = nINT + CERO;
                    CERO = nINT;
                    nINT = resultado;
                    Console.WriteLine(resultado);
                }
            }
        }
    
        Console.WriteLine("Laboratorio NO.07 ; TAREA ; Marcela Letran : 1102124");
        int valor1;
        bool usuario = false;
        bool proton = false;
        int aumento = 0;
        double uno = 1;
        double cero = 0;
        double resultado1;
        double resultado2;
        double resultado3;
        double x;
        double a;
        double n;
        double m = 0.00;
        double b = 0.00;

        do
        {
            Console.WriteLine("Ingrese un númeor entero distinto y mayor a 0");
            usuario = int.TryParse(Console.ReadLine(), out valor1);
            if (usuario)
            {
                if (valor1 > 0)
                {
                    proton = true;
                }
            }
        }
        while (!usuario || !proton);

        Console.WriteLine("Iteraciones"); 

        Console.WriteLine("El resultado de la operación: ");

        do
        {
            ++aumento;
            uno = aumento;
            Console.Write("1/"+ uno );
            if (aumento < valor1)
                {
                    Console.Write(" + ");
                }
            resultado1 = 1/uno;
            cero = cero + resultado1;
        }
        while(aumento < valor1);
        Console.WriteLine("  es: " + cero);

        aumento = 0;
        uno = 1;
        cero = 0;
        double potencia = 1;
        double Cero = 0;

        Console.WriteLine("El resultado de la operación: ");

        do
        {
            ++aumento;
            uno = aumento;
            Console.Write("1/2^(" + uno + ")");
            if (aumento < valor1)
                {
                    Console.Write(" + ");
                }

            while (Cero < uno)
            {
                ++Cero;
                potencia = potencia * 2;
            }
           
            resultado2 = 1/potencia;
            cero = cero + resultado2;
        }
        while (aumento < valor1);
        Console.WriteLine("  es: " + cero);

        uno = 1;
        cero = 0;
        Cero = 0;

        Console.WriteLine("Por favor ingresa el valor x operable");
        x = Convert.ToDouble(Console.ReadLine());
        Console.WriteLine("Por favor ingresa el valor a operable");
        a = Convert.ToDouble(Console.ReadLine());
        Console.WriteLine("Por favor ingresa el valor n operable");
        n = Convert.ToDouble(Console.ReadLine());

        Console.WriteLine("El resultado de la operación: ");

        do
        {
            uno = cero;
            Console.Write(x + "^" + cero +" * " + a + "^(" + n + "-" + cero +")" + " + ");
            m = Math.Pow(x,cero);
            b = Math.Pow(a,(n - cero));
            resultado3 = m * b;
            Cero = Cero + resultado3;
            ++cero;
        }
        while(cero <= n);
            Console.WriteLine("  es: " + Cero);
    }
}