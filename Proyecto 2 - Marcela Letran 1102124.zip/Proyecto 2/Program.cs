﻿using System.Security.Cryptography.X509Certificates;
using Proyecto_2;

class Program
{
    public static void Main ()
    {
        //clases declaradas en programa
        Jugador objJugador = new Jugador();
        Piezas objPiezas = new Piezas();
        Tablero objTablero = new Tablero();
        Dama objDama = new Dama();
        //variable para ejecutar menu
        string opMenu1 = " ";
        //Menu principal, se ejecutará hasta que el usuario selccione para finalizar programa
        do{
        Console.WriteLine("\nPor favor, elija una opción");
        Console.WriteLine("1. Visualizar tablero actual. \n2. Definir posición de la Dama. \n3. Agregar pieza a tablero. \n4. Visializar posibles movimeintos de Dama. \n5. Finalizar.");
        opMenu1 = Console.ReadLine() + "";

        switch (opMenu1)
        {
            case "1":
                objTablero.PrintTablero(objTablero.tablero);
            break;
            case "2":
            if (objDama.DAMAexistente == 0)
            {
                objDama.CoordenadasDAMA();
                objTablero.AgregarDama(objDama.filaDAMA, objDama.columnaDAMA);
                objTablero.MovimientosDAMA(objTablero.tablero, objDama.filaDAMA, objDama.columnaDAMA);
                objTablero.MovimeintosDiagonalRI(objTablero.tablero, objDama.filaDAMA, objDama.columnaDAMA);
                objTablero.MovimeintosDiagonalBD(objTablero.tablero, objDama.filaDAMA, objDama.columnaDAMA);
                objTablero.MovimeintosDiagonalRD(objTablero.tablero, objDama.filaDAMA, objDama.columnaDAMA);
                objTablero.MovimeintosDiagonalBI(objTablero.tablero, objDama.filaDAMA, objDama.columnaDAMA);
            }
            else
            { Console.WriteLine("Ya existe una dama en el tablero."); }
            break;
            case "3":
                objPiezas.SolicitarColorPieza();
                objPiezas.SolicitarTipoPieza(objPiezas.ColorPIEZA);
                objPiezas.CoordenadaXpieza(objPiezas.pieza);
                objPiezas.CoordenadaYpieza(objPiezas.filaPIEZA);
                objTablero.AgregarAtablero(objPiezas.filaPIEZA, objPiezas.columnaPIEZA, objPiezas.pieza);
                objTablero.MovimientosDAMA(objTablero.tablero, objDama.filaDAMA, objDama.columnaDAMA);
                objTablero.MovimeintosDiagonalRI(objTablero.tablero, objDama.filaDAMA, objDama.columnaDAMA);
                objTablero.MovimeintosDiagonalBD(objTablero.tablero, objDama.filaDAMA, objDama.columnaDAMA);
                objTablero.MovimeintosDiagonalRD(objTablero.tablero, objDama.filaDAMA, objDama.columnaDAMA);
                objTablero.MovimeintosDiagonalBI(objTablero.tablero, objDama.filaDAMA, objDama.columnaDAMA);
            break;
            case "4":
                objTablero.PrintMovimientos(objTablero.movimientos);
            break;
            case "5":
                Console.WriteLine("Gracias!");
            break;
            default:
                Console.WriteLine("Opción inválida.");
            break;
        }
        }while (opMenu1 != "5");
    }
}