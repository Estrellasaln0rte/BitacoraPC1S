﻿using System.Diagnostics.Contracts;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices.Marshalling;
using System.Security.Cryptography.X509Certificates;

namespace Proyecto_2;

public class Tablero
{
    //clases necesarias declaradas en tablero
    Piezas objPiezas = new Piezas();
    //matriz tablero decalrado (quemado) en código
    //tablero de 8 * 8 casillas, con la notación agregada a cada borde
    public string[,] tablero = new string[9, 9] { { "a", "0", "0", "0", "0", "0", "0", "0", "0" }, { "b", "0", "0", "0", "0", "0", "0", "0", "0" }, { "c", "0", "0", "0", "0", "0", "0", "0", "0" }, { "d", "0", "0", "0", "0", "0", "0", "0", "0" }, { "e", "0", "0", "0", "0", "0", "0", "0", "0" }, { "f", "0", "0", "0", "0", "0", "0", "0", "0" }, { "g", "0", "0", "0", "0", "0", "0", "0", "0" }, { "h", "0", "0", "0", "0", "0", "0", "0", "0" }, { " ", "1", "2", "3", "4", "5", "6", "7", "8" } };
    // Variable para verificar si Dama ya ha sido agregada
    public bool damaAgregada = false;
    public string[,] movimientos = new string[9, 9] { { "a", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  " }, { "b", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  " }, { "c", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  " }, { "d", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  " }, { "e", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  " }, { "f", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  " }, { "g", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  " }, { "h", "  ", "  ", "  ", "  ", "  ", "  ", "  ", "  " }, { " ", "1", "2", "3", "4", "5", "6", "7", "8" } };

    //función para imprimir en pantalla tablero
    public void PrintTablero(string[,] tablero)
    {
        Console.WriteLine(" ");
        for (int i = 0; i < tablero.GetLength(0); i++)
        {
            for (int j = 0; j < tablero.GetLength(1); j++)
            {
                Console.Write(tablero[i, j].ToString().PadRight(tablero.GetLength(1)));
            }
            Console.WriteLine(" ");
        }
    }
    //función para agregar a tablero la pieza solicitada
    public void AgregarAtablero(int filaPIEZA, int columnaPIEZA, string pieza)
    {
        if (columnaPIEZA != 10)
        {
            if (tablero[filaPIEZA, columnaPIEZA] == "0")
            {
                tablero[filaPIEZA, columnaPIEZA] = pieza + "  ";
            }
            else
            {
                Console.WriteLine("Esta casiila ya se encuantra ocupada en tablero.");
            }
            Console.WriteLine(pieza);
        }
    }
    //función para agregar Dama a tablero
    public void AgregarDama (int filaDAMA, int columnaDAMA)
    {
        if (columnaDAMA != 10)
        {
        if (tablero[filaDAMA, columnaDAMA] == "0")
        {
            tablero[filaDAMA, columnaDAMA] = "Dama Blanca";
        }
        else
        {
            Console.WriteLine("Esta casiila ya se encuantra ocupada en tablero.");
        }
        Console.WriteLine("Dama Blanca");
        }
    }
    //función para mostrar posibles movimeintos en tablero de dama
    //arriba, abajo, derecha e izquierda
    public string[,] MovimientosDAMA(string[,] tablero, int filaDAMA, int columnaDAMA)
    {
        //evaluar hacia arriba
        for (int i = filaDAMA - 1; i >= 0; i--)
        {

            if (tablero[i, columnaDAMA].IndexOf("Blanc") == -1)
            {
                movimientos[i, columnaDAMA] = movimientos[i, 0] + movimientos[8, columnaDAMA];
            }
            else
            {
                for (int j = i; j >= 0; j--) movimientos[j, columnaDAMA] = "  ";
                break;
            }
        }
        //evaluar hacia abajo
        for (int i = filaDAMA + 1; i <= 7; i++)
        {
            if (tablero[i, columnaDAMA].IndexOf("Blanc") == -1)
            {
                movimientos[i, columnaDAMA] = movimientos[i, 0] + movimientos[8, columnaDAMA];
            }
            else
            {
                for (int j = i; j <= 7; j++) movimientos[j, columnaDAMA] = "  ";
                break;
            }
        }
        //evaluar hacia la derecha
        for (int j = columnaDAMA + 1; j <= 8; j++)
        {
            if (tablero[filaDAMA, j].IndexOf("Blanc") == -1)
            {
                movimientos[filaDAMA, j] = movimientos[filaDAMA, 0] + movimientos[8, j]; ;
            }
            else
            {
                for (int k = j; k <= 8; k++) movimientos[filaDAMA, k] = "  ";
                break;
            }
        }
        //evaluar hacia la izquierda
        for (int j = columnaDAMA - 1; j > 0; j--)
        {
            if (tablero[filaDAMA, j].IndexOf("Blanc") == -1)
            {
                movimientos[filaDAMA, j] = movimientos[filaDAMA, 0] + movimientos[8, j]; ;
            }
            else
            {
                for (int k = j; k > 0; k--) movimientos[filaDAMA, k] = "  ";
                break;
            }
        }
        return movimientos;
    }
    //función para mostrar posibles movimeintos en tablero de dama
    //diagonal, arriba izquierda
    public string [,] MovimeintosDiagonalRI (string[,] tablero, int filaDAMA, int columnaDAMA)
    {
        int k = filaDAMA - 1;
        int l = columnaDAMA - 1;
        while (k >= 0 && l >= 0)
        {
            if (tablero[k, l].IndexOf("Blanc") == -1)
            {
                movimientos[k, l] = movimientos[--filaDAMA, 0] + movimientos[8, --columnaDAMA];
            }
            else
            {
                while (k >= 0 && l >= 0) movimientos[k--, l--] = "  ";
                break;
            }
            k--;
            l--;
        }
        return movimientos;
    }
    //función para mostrar posibles movimeintos en tablero de dama
    //diagonal, abajo derecho
    public string [,] MovimeintosDiagonalBD (string[,] tablero, int filaDAMA, int columnaDAMA)
    {
        int o = filaDAMA + 1;
        int p = columnaDAMA + 1;

        while (o < 8 && p < 8)
        {
            if (tablero[o, p].IndexOf("Blanc") == -1)
            {
                movimientos[o, p] = movimientos[++filaDAMA, 0] + movimientos[8, ++columnaDAMA];
            }
            else
            {
                while (o < 8 && p < 8) movimientos[o++, p++] = "  ";
                break;
            }
            o++;
            p++;
        }
        return movimientos;
    }
    //función para mostrar posibles movimeintos en tablero de dama
    //diagonal, arriba derecha
    public string[,] MovimeintosDiagonalRD(string[,] tablero, int filaDAMA, int columnaDAMA)
    {
        int i = filaDAMA - 1;
        int j = columnaDAMA + 1;
        while (i >= 0 && j < 8)
        {
            if (tablero[i, j].IndexOf("Blanc") == -1)
            {
                movimientos[i, j] = movimientos[--filaDAMA, 0] + movimientos[8, ++columnaDAMA];
            }
            else
            {
                while (i >= 0 && j < 8) movimientos[i--, j++] = "  ";
                break;
            }
            i--;
            j++;
        }
        return movimientos;
    }
    //función para mostrar posibles movimeintos en tablero de dama
    //diagonal, abajo izquierda
    public string[,] MovimeintosDiagonalBI(string[,] tablero, int filaDAMA, int columnaDAMA)
    {
        int i = filaDAMA + 1;
        int j = columnaDAMA - 1;

        while (i < 8 && j > 0)
        {
            if (tablero[i, j].IndexOf("Blanc") == -1)
            {
                movimientos[i, j] = movimientos[++filaDAMA, 0] + movimientos[8, --columnaDAMA];
            }
            else
            {
                while (i < 8 && j > 0) movimientos[i++, j--] = "  ";
                break;
            }
            i++;
            j--;
        }
        return movimientos;
    }
    //función para imprimir matriz con movimientos de dama
    public void PrintMovimientos (string[,] movimientos)
    {
        for (int i = 0; i < movimientos.GetLength(0); i++)
        {
            for (int j = 0; j < movimientos.GetLength(1); j++)
            {
                Console.Write(movimientos[i, j].ToString().PadRight(movimientos.GetLength(1)));
            }
            Console.WriteLine(" ");
        }
    }
}