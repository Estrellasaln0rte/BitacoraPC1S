﻿namespace Proyecto_2;

public class Dama
{
    //clases declaradas en dama
    Tablero objTablero = new Tablero();
    //variable para ejecutar menus en clase Dama
    public string opMenu = "";
    //variables para almacenar las coordenadas de la pieza a agregar por usuario a tablero en string
    public int filaDAMA = 0, columnaDAMA = 0;
    //Variable para verificar si Dama ya ha sido agregada
    public int DAMAexistente = 0;
    //función para alamcenar la fila en la cual agregar la pieza en tablero
    public int CoordenadaXdama()
    {
            Console.WriteLine("\nPor favor, ingrese la fila de la pieza a agregar, en notación del tablero:");
            opMenu = Console.ReadLine() + "";
            switch (opMenu)
            {
                case "a":
                    filaDAMA = 0;
                break;
                case "b":
                    filaDAMA = 1;
                break;
                case "c":
                    filaDAMA = 2;
                break;
                case "d":
                    filaDAMA = 3;
                break;
                case "e":
                    filaDAMA = 4;
                break;
                case "f":
                    filaDAMA = 5;
                break;
                case "g":
                    filaDAMA = 6;
                break;
                case "h":
                    filaDAMA = 7;
                break;
                default:
                    filaDAMA = 10;
                    Console.WriteLine("Opción inválida.");
                break;
            }
        return filaDAMA;
    }
    //función para alamcenar la columana en la cual agregar la pieza en tablero
    public int CoordenadaYdama(int filaDAMA)
    {
        if (filaDAMA != 10)
        {
            Console.WriteLine("\nPor favor, ingrese la calumna de la pieza a agregar, en notación del tablero:");
            opMenu = Console.ReadLine() + "";
            switch (opMenu)
            {
                case "1":
                    columnaDAMA = 1;
                break;
                case "2":
                    columnaDAMA = 2;
                break;
                case "3":
                    columnaDAMA = 3;
                break;
                case "4":
                    columnaDAMA = 4;
                break;
                case "5":
                    columnaDAMA = 5;
                break;
                case "6":
                    columnaDAMA = 6;
                break;
                case "7":
                    columnaDAMA = 7;
                break;
                case "8":
                    columnaDAMA = 8;
                break;
                default:
                    columnaDAMA = 10;
                    Console.WriteLine("Opción inválida.");
                break;
            }
        }
        else
        { columnaDAMA = 10; }
        return columnaDAMA;
    }
    //función para llamar coordenadas x y y de dama en programa, pasando por validación
    public int CoordenadasDAMA ()
    {
        CoordenadaXdama();
        CoordenadaYdama(filaDAMA);
        return DAMAexistente = 1;
    }
}