﻿using System.Runtime.CompilerServices;

namespace Proyecto_2;

public class Jugador
{

}