﻿using System.ComponentModel.DataAnnotations.Schema;
using System.Net;

namespace Proyecto_2;

public class Piezas
{
    //variable para ejecutar menus en clase Piezas
    public string opMenu = " ";
    //variables para evaluar la cantidad máxima de cierto tipo de pieza blanca
    public int ab = 0, tb = 0, cb = 0, pb = 0;
    //variables para evaluar la cantidad máxima de cierto tipo de pieza negra
    public int an = 0, tn = 0, cn = 0, pn = 0, r = 0;
    //variable para almacenar tipo de pieza a agregar
    public string pieza = " ";
    //variable para almacenar el color de la pieza
    public string ColorPIEZA = " ";
    //variables para almacenar las coordenadas de la pieza a agregar por usuario a tablero en string
    public int filaPIEZA = 0, columnaPIEZA = 0;

    //función para alamcenar el color de la pieza a gregar por usuario a tablero
    public string SolicitarColorPieza()
    {
        Console.WriteLine("\nPor favor elija una opción: \n1. Piezas Blancas. \n2. Piezas Negras. \n3. Rgresar.");
        opMenu = Console.ReadLine() + "";
        switch (opMenu)
        {
            case "1":
                ColorPIEZA = "blanca";
            break;
            case "2":
                ColorPIEZA = "negra";
            break;
            case "3":
                ColorPIEZA = "Color";
            break;
            default:
                Console.WriteLine("Opción inválida.");
            break;
        }
        return ColorPIEZA;
    }
    //función para alamcenar el tipo de la pieza a gregar por usuario a tablero
    //Evalua el tipo d epieza, limitando a 2 alfiles, 2 caballos, 2 torres, 8 peones y 1 rey, para agregar a tablero
    public string SolicitarTipoPieza(string ColorPIEZA)
    {
        if (ColorPIEZA != "Color")
        {
            if (ColorPIEZA == "blanca")
            {
                //Menu piezas blancas
                Console.WriteLine("\nPor favor, elija el tipo de pieza: \n1. Alfil. \n2. Caballo. \n3. Torre. \n4. Peón. \n5. Regresar.");
                opMenu = Console.ReadLine() + "";
                switch (opMenu)
                {
                    case "1":
                        ab++;
                        if (ab <= 2)
                        { pieza = "Alfil Blanco"; }
                        else
                        { Console.WriteLine("Ya existen los alfiles blancos máximos en el tablero."); pieza = "0"; }
                    break;
                    case "2":
                        cb++;
                        if (cb <= 2)
                        { pieza = "Caballo Blanco"; }
                        else
                        { Console.WriteLine("Ya existen los caballos blancos máximos en el tablero."); pieza = "0"; }
                    break;
                    case "3":
                        tb++;
                        if (tb <= 2)
                        { pieza = "Torre Blanca"; }
                        else
                        { Console.WriteLine("Ya existen las torres blancas máximas en el tablero."); pieza = "0"; }
                    break;
                    case "4":
                        pb++;
                        if (pb <= 8)
                        { pieza = "Peón Blanco"; }
                        else
                        { Console.WriteLine("Ya existen los peones blancos máximos en el tablero."); pieza = "0"; }
                    break;
                    case "5":
                        pieza = "0";
                    break;
                    default:
                        pieza = "0";
                        Console.WriteLine("Opción Inválida.");
                    break;
                }
            }
            else
            {
                //Menu piezas negras
                Console.WriteLine("\nPor favor, elija el tipo de pieza: \n1. Alfil. \n2. Caballo. \n3. Torre. \n4. Peón.\n5. Rey \n6. Regresar");
                opMenu = Console.ReadLine() + "";
                switch (opMenu)
                {
                    case "1":
                        an++;
                        if (an <= 2)
                        { pieza = "Alfil Negro"; }
                        else
                        { Console.WriteLine("Ya existen los alfiles negros máximos en el tablero."); pieza = "0"; }
                    break;
                    case "2":
                        cn++;
                        if (cn <= 2)
                        { pieza = "Caballo Negro"; }
                        else
                        { Console.WriteLine("Ya existen los caballos negros máximos en el tablero."); pieza = "0"; }
                    break;
                    case "3":
                        tn++;
                        if (tn <= 2)
                        { pieza = "Torre Negra"; }
                        else
                        { Console.WriteLine("Ya existen las torres negras máximas en el tablero."); pieza = "0"; }
                    break;
                    case "4":
                        pn++;
                        if (pn <= 8)
                        { pieza = "Peón Negro"; }
                        else
                        { Console.WriteLine("Ya existen los peones negros máximos en el tablero."); pieza = "0"; }
                    break;
                    case "5":
                        r++;
                        if (r <= 1)
                        { pieza = "Rey"; }
                        else
                        { Console.WriteLine("Ya existen un rey en el tablero."); pieza = "0"; }
                    break;
                    case "6":
                        pieza = "0";
                    break;
                    default:
                        pieza = "0";
                        Console.WriteLine("Opción Inválida.");
                    break;
                }
            }
        }
        else
        { pieza = "0"; }
        return pieza;
    }
    //función para alamcenar la fila en la cual agregar la pieza en tablero
    public int CoordenadaXpieza(string pieza)
    {
        if (pieza != "0")
        {
            Console.WriteLine("\nPor favor, ingrese la fila de la pieza a agregar, en notación del tablero:");
            opMenu = Console.ReadLine() + "";
            switch (opMenu)
            {
                case "a":
                    filaPIEZA = 0;
                break;
                case "b":
                    filaPIEZA = 1;
                break;
                case "c":
                    filaPIEZA = 2;
                break;
                case "d":
                    filaPIEZA = 3;
                break;
                case "e":
                    filaPIEZA = 4;
                break;
                case "f":
                    filaPIEZA = 5;
                break;
                case "g":
                    filaPIEZA = 6;
                break;
                case "h":
                    filaPIEZA = 7;
                break;
                default:
                    filaPIEZA = 10;
                    Console.WriteLine("Opción inválida.");
                break;
            }
        }//uwu
        else
        { filaPIEZA = 10; }
        return filaPIEZA;
    }
    //función para alamcenar la columana en la cual agregar la pieza en tablero
    public int CoordenadaYpieza(int filaPIEZA)
    {
        if (filaPIEZA != 10)
        {
            Console.WriteLine("\nPor favor, ingrese la calumna de la pieza a agregar, en notación del tablero:");
            opMenu = Console.ReadLine() + "";
            switch (opMenu)
            {
                case "1":
                    columnaPIEZA = 1;
                break;
                case "2":
                    columnaPIEZA = 2;
                break;
                case "3":
                    columnaPIEZA = 3;
                break;
                case "4":
                    columnaPIEZA = 4;
                break;
                case "5":
                    columnaPIEZA = 5;
                break;
                case "6":
                    columnaPIEZA = 6;
                break;
                case "7":
                    columnaPIEZA = 7;
                break;
                case "8":
                    columnaPIEZA = 8;
                break;
                default:
                    columnaPIEZA = 10;
                    Console.WriteLine("Opción inválida.");
                break;
            }
        }
        else
        { columnaPIEZA = 10; }
        return columnaPIEZA;
    }
}